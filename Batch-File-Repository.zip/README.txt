> This repository only has windows 7-11 file code if you use any other OS system please do not download this if your on a different OS.

> Please don't edit any of these files and please don't remove any of the credits if are editing these files do not remove the credits just add your own commands.

> Hope you enjoy this also this is my first repository and code file so please leave feedback!

> Please run the Usertool with admin permissions!